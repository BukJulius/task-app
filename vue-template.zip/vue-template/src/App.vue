<template>
  <div id="app" class="app">
    <router-view />
  </div>
</template>
