function get(method) {
  return fetch(fullUrl(method), {
    method: 'GET',
    cache: 'no-cache',
    mode: 'cors',
    credentials: 'include'
  }).then(convertResponse)
    .catch(errorHandler)
}

function post(method, body) {
  return fetch(fullUrl(method), {
    method: 'POST',
    cache: 'no-cache',
    mode: 'cors',
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  }).then(convertResponse)
    .catch(errorHandler)
}

async function convertResponse(response) {
  try {
    const contentType = response.headers.get('content-type')
    if (response.status === 200) {
      if (contentType) return { data: {} }

      const data = await response.json()
      return { data }
    }
    const error = {
      status: response.status
    }

    if (contentType) {
      error.data = await response.json()
    }

    return error
  } catch (error) {
    return {
      status: response.status
    }
  }
}


function errorHandler() {
  return {
    error: 500
  }
}

function fullUrl(path) {
  return `${BaseUrl}${path}`
}

export default {
  get,
  post
}
